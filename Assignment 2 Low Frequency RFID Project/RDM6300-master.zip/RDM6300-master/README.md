# RDM6300
RFID Library for RDM6300 TTL module

Not for commercial use

Connect TX pin of RDM630 module to PIN2 of Arduino

![Alt text](/rdm6300_decoder_wiring.png?raw=true "Wiring Diagram")
